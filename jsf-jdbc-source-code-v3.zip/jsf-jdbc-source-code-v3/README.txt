JSF for Beginners -- JDBC Database Example
==========================================

This directory contains the source code and SQL scripts for the JSF JDBC example.

I created multiple versions of the application.

> Version 1: contains only the code for listing students

> Version 2: builds on version 1 and adds code for adding students

> Version 3: builds on version 2 and adds code for updating students

> Version 4: builds on version 3 and adds code deleting students

> Final Version: contains combination of all versions

If you want to walk through app like I do in the separate videos then you can pick the appropriate version.

If you want to see all of the code for the final app, then just choose the final app version.


